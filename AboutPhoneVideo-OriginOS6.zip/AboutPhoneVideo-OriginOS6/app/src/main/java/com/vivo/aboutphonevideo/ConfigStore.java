package com.vivo.aboutphonevideo;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import java.io.File;

public final class ConfigStore {
    public static final String PREFS_NAME = "about_phone_video_prefs";

    public static final String KEY_CARD_ENABLED = "card_enabled";
    public static final String KEY_CARD_MUTED = "card_muted";
    public static final String KEY_CARD_VOLUME = "card_volume";
    public static final String KEY_CARD_CORNER_DP = "card_corner_dp";

    public static final String KEY_BG_ENABLED = "bg_enabled";
    public static final String KEY_BG_MUTED = "bg_muted";
    public static final String KEY_BG_VOLUME = "bg_volume";
    public static final String KEY_BG_DIM_ALPHA = "bg_dim_alpha";
    public static final String KEY_BG_CARD_ALPHA = "bg_card_alpha";

    public static final String FILE_CARD_VIDEO = "card_video.mp4";
    public static final String FILE_BG_VIDEO = "bg_video.mp4";

    private ConfigStore() {}

    public static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public static File getCardVideoFile(Context context) {
        return new File(context.getFilesDir(), FILE_CARD_VIDEO);
    }

    public static File getBgVideoFile(Context context) {
        return new File(context.getFilesDir(), FILE_BG_VIDEO);
    }

    public static boolean hasCardVideo(Context context) {
        File f = getCardVideoFile(context);
        return f.exists() && f.length() > 0;
    }

    public static boolean hasBgVideo(Context context) {
        File f = getBgVideoFile(context);
        return f.exists() && f.length() > 0;
    }

    public static Bundle toBundle(Context context) {
        SharedPreferences sp = prefs(context);
        Bundle b = new Bundle();
        b.putBoolean(KEY_CARD_ENABLED, sp.getBoolean(KEY_CARD_ENABLED, true));
        b.putBoolean("card_has_video", hasCardVideo(context));
        b.putBoolean(KEY_CARD_MUTED, sp.getBoolean(KEY_CARD_MUTED, true));
        b.putInt(KEY_CARD_VOLUME, sp.getInt(KEY_CARD_VOLUME, 60));
        b.putInt(KEY_CARD_CORNER_DP, sp.getInt(KEY_CARD_CORNER_DP, 18));

        b.putBoolean(KEY_BG_ENABLED, sp.getBoolean(KEY_BG_ENABLED, true));
        b.putBoolean("bg_has_video", hasBgVideo(context));
        b.putBoolean(KEY_BG_MUTED, sp.getBoolean(KEY_BG_MUTED, true));
        b.putInt(KEY_BG_VOLUME, sp.getInt(KEY_BG_VOLUME, 40));
        b.putInt(KEY_BG_DIM_ALPHA, sp.getInt(KEY_BG_DIM_ALPHA, 35));
        b.putInt(KEY_BG_CARD_ALPHA, sp.getInt(KEY_BG_CARD_ALPHA, 75));
        return b;
    }
}
