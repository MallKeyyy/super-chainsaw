# AboutPhoneVideo (OriginOS 6 LSPosed Module)

Companion LSPosed module designed to work alongside **Vivo Tool 1.1.0** (`com.skb8.vivotool`).

## Features
- **About Phone Image Video**: Replaces the OriginOS 6 About Phone banner (`about_phone_origin_os_rom16` / `about_phone_origin_os_rom` / `about_phone_rom15`) with a rounded, looping `TextureView` + `MediaPlayer` video with mute, volume, and corner-radius controls.
- **About Phone Background Video**: Plays a full-screen looping video behind `VivoAboutPhoneFragment` with adjustable dark scrim dim and info-card opacity so text stays legible, and cleans up automatically when you leave About Phone.
- **SELinux-safe Media Bridge**: Uses an exported read-only `ContentProvider` (`com.vivo.aboutphonevideo.provider`) so `com.android.settings` streams your selected videos with zero storage permission or SELinux issues.

## Build APK without a PC (GitHub Actions)
1. Unzip and push this folder to a GitHub repo (e.g. via Termux + `gh repo create`).
2. Open the **Actions** tab → **Build AboutPhoneVideo APK** → download `AboutPhoneVideo-OriginOS6-debug`.
3. Install the APK, enable it in **LSPosed** for **System Settings** (`com.android.settings`), pick your videos, force stop Settings, and open **About phone**.
